/* ========== 孩子积分管理 App - 前端逻辑 ========== */

// 状态管理
const state = {
  token: localStorage.getItem('token') || null,
  user: JSON.parse(localStorage.getItem('user') || 'null'),
  tasks: [],
  children: [],
  submissions: [],
  pointsLogs: [],
  currentTab: '',
  currentFilter: 'all',  // 任务状态筛选
  childrenFilter: 'all', // 积分页孩子筛选
  editingTask: null,     // 正在操作的积分目标
};

// ========== 工具函数 ==========
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

function showToast(msg, duration = 2200) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.add('hidden'), duration);
}

function esc(str) {
  return String(str || '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function openModal(html) {
  $('#modal').innerHTML = html;
  $('#modal-overlay').classList.remove('hidden');
}
function closeModal() {
  $('#modal-overlay').classList.add('hidden');
}
$('#modal-overlay')?.addEventListener('click', (e) => {
  if (e.target === e.currentTarget) closeModal();
});

// 颜色映射（用于孩子头像）
const COLORS = ['#4F8EF7', '#22C55E', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#14B8A6', '#F97316'];

// ========== API 封装 ==========
async function api(path, method = 'GET', body = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
  };
  if (state.token) opts.headers['Authorization'] = 'Bearer ' + state.token;
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch('/api' + path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401) {
      logout();
    }
    throw new Error(data.error || '请求失败');
  }
  return data;
}

// ========== 认证 ==========
function saveSession(token, user) {
  state.token = token;
  state.user = user;
  localStorage.setItem('token', token);
  localStorage.setItem('user', JSON.stringify(user));
}
function logout() {
  state.token = null;
  state.user = null;
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  showLogin();
}

// ========== 页面切换 ==========
function showLogin() {
  $('#login-page').classList.remove('hidden');
  $('#app').classList.add('hidden');
}
function showApp() {
  $('#login-page').classList.add('hidden');
  $('#app').classList.remove('hidden');
  renderHeader();
  renderNav();
  // 默认 tab
  state.currentTab = state.user.role === 'parent' ? 'tasks' : 'tasks';
  loadTab(state.currentTab);
}

function renderHeader() {
  const u = state.user;
  $('#header-avatar').textContent = u.role === 'parent' ? '👨‍👩‍👧' : (u.child_name || '👤').slice(0, 1);
  $('#header-avatar').style.background = u.avatar_color || COLORS[0];
  $('#header-name').textContent = u.role === 'parent' ? '家长' : (u.child_name || '孩子');
  $('#header-role').textContent = u.role === 'parent' ? '管理员' : '小当家';
  $('#header-points').textContent = u.role === 'parent' ? '积分管理' : (u.points ?? 0) + ' 分';
}

// ========== 底部导航 ==========
function renderNav() {
  const nav = $('#bottom-nav');
  const isParent = state.user.role === 'parent';
  const items = isParent ? [
    { key: 'tasks', icon: '📋', label: '任务' },
    { key: 'publish', icon: '➕', label: '发布' },
    { key: 'audit', icon: '✅', label: '审核' },
    { key: 'points', icon: '🏆', label: '积分' },
    { key: 'children', icon: '👦', label: '孩子' },
  ] : [
    { key: 'tasks', icon: '📋', label: '任务' },
    { key: 'points', icon: '🏆', label: '我的积分' },
    { key: 'profile', icon: '👤', label: '我的' },
  ];
  nav.innerHTML = items.map(it => `
    <div class="nav-item ${state.currentTab === it.key ? 'active' : ''}" data-tab="${it.key}">
      <span class="nav-icon">${it.icon}</span>
      <span class="nav-label">${it.label}</span>
    </div>
  `).join('');
  nav.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => {
      state.currentTab = item.dataset.tab;
      renderNav();
      loadTab(item.dataset.tab);
    });
  });
}

function loadTab(tab) {
  if (tab === 'tasks') loadTasks();
  else if (tab === 'publish') renderPublish();
  else if (tab === 'audit') loadAudit();
  else if (tab === 'points') loadPoints();
  else if (tab === 'children') loadChildren();
  else if (tab === 'profile') renderProfile();
}

// ========== 任务页 ==========
async function loadTasks() {
  const isParent = state.user.role === 'parent';
  try {
    const data = await api('/tasks');
    state.tasks = data.tasks;
    const content = $('#content');

    if (isParent) {
      // 家长：任务管理 + 状态筛选
      const counts = {
        all: data.tasks.length,
        pending: data.tasks.filter(t => t.status === 'pending').length,
        claimed: data.tasks.filter(t => t.status === 'claimed').length,
        completed: data.tasks.filter(t => t.status === 'completed').length,
        approved: data.tasks.filter(t => t.status === 'approved').length,
      };
      const filterTabs = [
        ['all', '全部', counts.all],
        ['pending', '待认领', counts.pending],
        ['claimed', '进行中', counts.claimed],
        ['completed', '待审核', counts.completed],
        ['approved', '已完成', counts.approved],
      ];
      content.innerHTML = `
        <div class="status-strip">
          ${filterTabs.map(([k, label, c]) => `
            <div class="status-strip-item ${state.currentFilter === k ? 'active' : ''}" data-filter="${k}">
              <span class="count">${c}</span>${label}
            </div>`).join('')}
        </div>
        <div class="list-toolbar">
          <div class="section-title" style="margin:0">任务列表</div>
          <button class="btn btn-primary btn-sm" onclick="showPublishModal()">＋ 发布任务</button>
        </div>
        ${data.tasks.length === 0 ? renderEmpty('📭', '还没有任务，点击"发布任务"创建一个吧') :
          data.tasks.filter(t => state.currentFilter === 'all' || t.status === state.currentFilter)
            .map(renderTaskCardParent).join('')}
      `;
      content.querySelectorAll('.status-strip-item').forEach(el => {
        el.addEventListener('click', () => {
          state.currentFilter = el.dataset.filter;
          loadTasks();
        });
      });
    } else {
      // 孩子：任务池 + 我的任务
      const myTasks = data.tasks.filter(t => t.claimed_by === state.user.id || t.assigned_to === state.user.id);
      const openTasks = data.tasks.filter(t => t.status === 'pending');
      content.innerHTML = `
        <div class="section-title">🔥 可认领任务</div>
        ${openTasks.length === 0 ? renderEmpty('🎉', '暂时没有可认领的任务') : openTasks.map(renderTaskCardChild).join('')}
        <div class="section-title">📌 我的任务</div>
        ${myTasks.length === 0 ? renderEmpty('📋', '你还没有认领任务') : myTasks.map(renderTaskCardChild).join('')}
      `;
    }
  } catch (e) {
    $('#content').innerHTML = renderEmpty('⚠️', e.message);
  }
}

function renderEmpty(icon, text) {
  return `<div class="empty"><div class="empty-icon">${icon}</div><div>${esc(text)}</div></div>`;
}

function catLabel(cat) {
  return cat === 'homework' ? '作业' : '家务';
}
function catClass(cat) {
  return cat === 'homework' ? 'cat-homework' : 'cat-chore';
}
function statusLabel(s) {
  const map = { pending: '待认领', claimed: '进行中', completed: '待审核', approved: '已完成', rejected: '已驳回', expired: '已过期' };
  return map[s] || s;
}
function statusClass(s) {
  return 'st-' + s;
}

function childNameOf(task) {
  const c = state.children.find(ch => ch.id === task.assigned_to || ch.id === task.claimed_by);
  return c ? c.child_name : '待认领';
}

// 家长任务卡片
function renderTaskCardParent(t) {
  return `
    <div class="card task-card" onclick="showTaskDetail(${t.id})">
      <div class="task-card-header">
        <span class="task-title">${esc(t.title)}</span>
        <span class="task-cat ${catClass(t.category)}">${catLabel(t.category)}</span>
      </div>
      ${t.description ? `<div class="task-desc">${esc(t.description)}</div>` : ''}
      <div class="task-meta">
        <span class="task-points">+${t.base_points} 分</span>
        ${t.assigned_to || t.claimed_by ? `<span>👦 ${esc(childNameOf(t))}</span>` : '<span>🏷 待认领</span>'}
        <span class="status-tag ${statusClass(t.status)}">${statusLabel(t.status)}</span>
      </div>
      ${t.status === 'completed' ? '<div class="time-text" style="margin-top:6px">⏳ 等待你审核</div>' : ''}
    </div>`;
}

// 孩子任务卡片
function renderTaskCardChild(t) {
  const isMine = t.claimed_by === state.user.id || t.assigned_to === state.user.id;
  return `
    <div class="card task-card" onclick="showChildTask(${t.id})">
      <div class="task-card-header">
        <span class="task-title">${esc(t.title)}</span>
        <span class="task-cat ${catClass(t.category)}">${catLabel(t.category)}</span>
      </div>
      ${t.description ? `<div class="task-desc">${esc(t.description)}</div>` : ''}
      <div class="task-meta">
        <span class="task-points">+${t.base_points} 分</span>
        <span class="status-tag ${statusClass(t.status)}">${statusLabel(t.status)}</span>
      </div>
      ${t.status === 'pending' ? '<button class="btn btn-success btn-sm" style="margin-top:10px;width:100%" onclick="event.stopPropagation();claimTask(' + t.id + ')">认领这个任务</button>' : ''}
    </div>`;
}

// ========== 任务详情（家长） ==========
async function showTaskDetail(id) {
  const t = state.tasks.find(x => x.id === id);
  if (!t) return;
  const child = state.children.find(c => c.id === (t.assigned_to || t.claimed_by));
  const actions = [];
  if (t.status === 'pending' || t.status === 'claimed') {
    actions.push(`<button class="btn btn-outline-danger" onclick="closeModal();deleteTask(${t.id})">删除任务</button>`);
  }
  openModal(`
    <div class="modal-title">任务详情</div>
    <div style="text-align:center;margin-bottom:14px">
      <span class="task-cat ${catClass(t.category)}">${catLabel(t.category)}</span>
      <span class="status-tag ${statusClass(t.status)}">${statusLabel(t.status)}</span>
    </div>
    <div class="form-group"><label>任务名称</label><div>${esc(t.title)}</div></div>
    ${t.description ? `<div class="form-group"><label>说明</label><div>${esc(t.description)}</div></div>` : ''}
    <div class="form-group"><label>基础积分</label><div style="color:var(--warning);font-size:22px;font-weight:700">${t.base_points} 分</div></div>
    ${child ? `<div class="form-group"><label>负责孩子</label><div>${esc(child.child_name)}</div></div>` : '<div class="form-group"><label>负责孩子</label><div>待认领</div></div>'}
    ${t.deadline ? `<div class="form-group"><label>截止时间</label><div>${esc(t.deadline)}</div></div>` : ''}
    ${t.actual_points ? `<div class="form-group"><label>实际发放</label><div style="color:var(--success);font-weight:700">${t.actual_points} 分</div></div>` : ''}
    ${t.reject_reason ? `<div class="form-group"><label>驳回原因</label><div style="color:var(--danger)">${esc(t.reject_reason)}</div></div>` : ''}
    <div class="modal-actions">
      ${actions.length ? actions.join('') : ''}
      <button class="btn btn-primary" onclick="closeModal()">关闭</button>
    </div>
  `);
}

async function deleteTask(id) {
  try {
    await api('/tasks/' + id, 'DELETE');
    showToast('任务已删除');
    loadTasks();
  } catch (e) { showToast(e.message); }
}

// ========== 孩子任务操作 ==========
async function claimTask(id) {
  try {
    await api(`/tasks/${id}/claim`, 'POST');
    showToast('认领成功！快去完成吧 💪');
    loadTasks();
  } catch (e) { showToast(e.message); }
}

async function showChildTask(id) {
  const t = state.tasks.find(x => x.id === id);
  if (!t) return;
  let body = '';
  if (t.status === 'pending') {
    body = `<button class="btn btn-success" style="width:100%" onclick="closeModal();claimTask(${t.id})">认领任务</button>`;
  } else if (t.status === 'claimed' && t.claimed_by === state.user.id && !t.has_submission) {
    body = `<button class="btn btn-primary" style="width:100%" onclick="closeModal();showSubmitModal(${t.id})">📸 上传完成照片</button>`;
  } else if (t.status === 'completed' && t.claimed_by === state.user.id) {
    body = `<div class="info-block">⏳ 你的完成已提交，等待家长审核中...</div>`;
  } else if (t.status === 'approved') {
    body = `<div class="info-block" style="background:#D1FAE5;color:#065F46">✅ 已完成！获得 ${t.actual_points || t.base_points} 分</div>`;
  }
  openModal(`
    <div class="modal-title">${esc(t.title)}</div>
    <div style="text-align:center;margin-bottom:14px">
      <span class="task-cat ${catClass(t.category)}">${catLabel(t.category)}</span>
      <span class="status-tag ${statusClass(t.status)}">${statusLabel(t.status)}</span>
    </div>
    ${t.description ? `<div style="margin-bottom:12px;color:var(--text-light)">${esc(t.description)}</div>` : ''}
    <div style="text-align:center;margin-bottom:16px;color:var(--warning);font-size:24px;font-weight:700">${t.base_points} 分</div>
    ${body}
    <div style="margin-top:10px"><button class="btn btn-outline" style="width:100%" onclick="closeModal()">关闭</button></div>
  `);
}

// 提交完成
function showSubmitModal(taskId) {
  let imageBase64 = '';
  openModal(`
    <div class="modal-title">完成任务</div>
    <div class="form-group">
      <label>上传完成照片</label>
      <div class="photo-upload" id="photo-upload" onclick="document.getElementById('file-input').click()">
        <div class="photo-icon">📷</div>
        <p>点击拍照或从相册选择</p>
        <input type="file" id="file-input" accept="image/*" capture="environment">
      </div>
      <img id="preview-img" class="image-preview hidden" alt="预览">
    </div>
    <div class="form-group">
      <label>备注（可选）</label>
      <textarea id="submit-note" placeholder="说说你是怎么完成的..."></textarea>
    </div>
    <div class="modal-actions">
      <button class="btn btn-outline" onclick="closeModal()">取消</button>
      <button class="btn btn-primary" id="submit-btn" onclick="submitTask(${taskId}, '')">提交完成</button>
    </div>
  `);
  const fileInput = $('#file-input');
  fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      imageBase64 = ev.target.result;
      const preview = $('#preview-img');
      preview.src = imageBase64;
      preview.classList.remove('hidden');
      $('#photo-upload').classList.add('active');
    };
    reader.readAsDataURL(file);
  });
  window.__submitImage = () => imageBase64;
}

async function submitTask(taskId, _) {
  const image = window.__submitImage ? window.__submitImage() : '';
  const note = $('#submit-note')?.value || '';
  if (!image) {
    showToast('请先上传完成照片');
    return;
  }
  try {
    $('#submit-btn').disabled = true;
    $('#submit-btn').textContent = '提交中...';
    await api(`/tasks/${taskId}/submit`, 'POST', { image, note });
    showToast('提交成功，等待家长审核 🎉');
    closeModal();
    loadTasks();
  } catch (e) {
    showToast(e.message);
    $('#submit-btn').disabled = false;
    $('#submit-btn').textContent = '提交完成';
  }
}

// ========== 发布任务（家长） ==========
function renderPublish() {
  const content = $('#content');
  content.innerHTML = `
    <div class="info-block">💡 发布任务后，孩子可以在"任务"页认领；你也可以选择"指定孩子"，任务将直接分配给该孩子。</div>
    <div class="card">
      <div class="modal-title" style="margin-bottom:16px">📝 发布新任务</div>
      <div class="form-group">
        <label>任务类型</label>
        <div class="category-select">
          <div class="cat-option active" data-cat="chore" onclick="selectCat(this)">🧹 家务</div>
          <div class="cat-option" data-cat="homework" onclick="selectCat(this)">📖 作业</div>
        </div>
      </div>
      <div class="form-group">
        <label>任务名称</label>
        <input type="text" id="task-title" placeholder="例如：洗碗、整理房间、完成数学作业...">
      </div>
      <div class="form-group">
        <label>任务说明（可选）</label>
        <textarea id="task-desc" placeholder="详细描述任务要求..."></textarea>
      </div>
      <div class="form-group">
        <label>基础积分</label>
        <div class="points-stepper">
          <button class="stepper-btn" onclick="stepPoints(-1)">−</button>
          <span class="points-value" id="task-points">5</span>
          <button class="stepper-btn" onclick="stepPoints(1)">+</button>
        </div>
      </div>
      <div class="form-group">
        <label>指定孩子（留空则开放认领）</label>
        <select id="task-assign">
          <option value="">🔥 开放认领</option>
          ${state.children.map(c => `<option value="${c.id}">👦 ${esc(c.child_name)}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label>截止时间（可选）</label>
        <input type="datetime-local" id="task-deadline">
      </div>
      <button class="btn btn-primary btn-block" onclick="publishTask()">发布任务</button>
    </div>
  `;
}

let selectedCat = 'chore';
function selectCat(el) {
  $$('.cat-option').forEach(x => x.classList.remove('active'));
  el.classList.add('active');
  selectedCat = el.dataset.cat;
}
function stepPoints(delta) {
  const v = parseInt($('#task-points').textContent) + delta;
  $('#task-points').textContent = Math.max(1, v);
}

async function publishTask() {
  const title = $('#task-title').value.trim();
  if (!title) return showToast('请输入任务名称');
  const desc = $('#task-desc').value.trim();
  const points = parseInt($('#task-points').textContent);
  const assigned = $('#task-assign').value ? parseInt($('#task-assign').value) : null;
  const deadline = $('#task-deadline').value || null;
  try {
    await api('/tasks', 'POST', { title, category: selectedCat, description: desc, base_points: points, assigned_to: assigned, deadline });
    showToast('任务发布成功！');
    state.currentTab = 'tasks';
    state.currentFilter = 'all';
    renderNav();
    loadTasks();
  } catch (e) { showToast(e.message); }
}

// ========== 审核页（家长） ==========
async function loadAudit() {
  try {
    const data = await api('/submissions');
    state.submissions = data.submissions;
    const pending = data.submissions.filter(s => s.task_status === 'completed');
    $('#content').innerHTML = `
      <div class="section-title">✅ 待审核任务 <span class="status-tag st-completed" style="margin-left:6px">${pending.length}</span></div>
      ${pending.length === 0 ? renderEmpty('🎉', '太棒了，没有待审核的任务') :
        pending.map(s => renderAuditCard(s)).join('')}
    `;
  } catch (e) {
    $('#content').innerHTML = renderEmpty('⚠️', e.message);
  }
}

function renderAuditCard(s) {
  return `
    <div class="card">
      <div class="task-card-header">
        <span class="task-title">${esc(s.task_title)}</span>
        <span class="task-cat ${catClass(s.category)}">${catLabel(s.category)}</span>
      </div>
      <div class="task-meta" style="margin-bottom:10px">
        <span>👦 ${esc(s.child_name)}</span>
        <span>基础 ${s.base_points} 分</span>
        <span class="time-text">${esc(s.submitted_at)}</span>
      </div>
      ${s.image ? `<img src="${s.image}" class="audit-img" onclick="window.open('${s.image}')" alt="完成照片">` : '<div class="info-block">⚠️ 未上传照片</div>'}
      ${s.note ? `<div style="font-size:13px;color:var(--text-light);margin-bottom:10px">💬 ${esc(s.note)}</div>` : ''}
      <div class="form-group" style="margin-top:10px">
        <label>实际发放积分（可修改）</label>
        <div class="points-stepper">
          <button class="stepper-btn" onclick="stepAuditPoints(-1, ${s.id})">−</button>
          <span class="points-value" id="audit-points-${s.id}">${s.base_points}</span>
          <button class="stepper-btn" onclick="stepAuditPoints(1, ${s.id})">+</button>
        </div>
      </div>
      <div class="form-group">
        <label>驳回原因（驳回时填写）</label>
        <input type="text" id="reject-reason-${s.id}" placeholder="例如：没洗干净，请重新完成">
      </div>
      <div class="modal-actions">
        <button class="btn btn-danger" onclick="reviewSubmission(${s.id}, false)">✕ 驳回</button>
        <button class="btn btn-success" onclick="reviewSubmission(${s.id}, true)">✓ 通过发积分</button>
      </div>
    </div>`;
}

function stepAuditPoints(delta, subId) {
  const el = document.getElementById(`audit-points-${subId}`);
  const v = parseInt(el.textContent) + delta;
  el.textContent = Math.max(0, v);
}

async function reviewSubmission(subId, approve) {
  const actual_points = parseInt(document.getElementById(`audit-points-${subId}`).textContent);
  const reject_reason = document.getElementById(`reject-reason-${subId}`)?.value.trim();
  try {
    await api(`/submissions/${subId}/review`, 'POST', { approve, actual_points, reject_reason });
    showToast(approve ? `已通过，发放 ${actual_points} 分 ✅` : '已驳回');
    loadAudit();
  } catch (e) { showToast(e.message); }
}

// ========== 积分页 ==========
async function loadPoints() {
  const isParent = state.user.role === 'parent';
  try {
    if (isParent) {
      // 家长：排行榜 + 全部流水 + 手动调整
      const data = await api('/children');
      state.children = data.children;
      // 按积分排序
      const ranked = [...state.children].sort((a, b) => b.points - a.points);
      const logsData = await api('/points/logs');
      $('#content').innerHTML = `
        <div class="section-title">🏆 积分排行榜</div>
        ${ranked.length === 0 ? renderEmpty('👶', '还没有添加孩子，请先到"孩子"页添加') : ranked.map((c, i) => `
          <div class="rank-card">
            <div class="rank-num ${i < 3 ? 'top' + (i + 1) : ''}">${i + 1}</div>
            <span class="avatar" style="background:${c.avatar_color}">${esc(c.child_name).slice(0,1)}</span>
            <div class="rank-info"><div class="rank-name">${esc(c.child_name)}</div><div style="font-size:12px;color:var(--text-light)">${c.points} 分</div></div>
            <button class="btn btn-sm btn-outline" onclick="showAdjustModal(${c.id})">调整</button>
          </div>`).join('')}
        <div class="section-title" style="margin-top:20px">📜 积分流水</div>
        ${logsData.logs.length === 0 ? renderEmpty('📊', '暂无积分记录') : logsData.logs.slice(0, 50).map(renderLogItem).join('')}
      `;
    } else {
      // 孩子：我的积分 + 流水
      const logsData = await api('/points/logs');
      $('#content').innerHTML = `
        <div class="points-hero">
          <div class="big-label">我的积分</div>
          <div class="big-number">${state.user.points ?? 0}</div>
          <div style="font-size:13px;opacity:0.85;margin-top:4px">继续加油，做更多任务赚积分！</div>
        </div>
        <div class="section-title">📜 积分明细</div>
        ${logsData.logs.length === 0 ? renderEmpty('📊', '还没有积分记录') : logsData.logs.map(renderLogItem).join('')}
      `;
    }
  } catch (e) {
    $('#content').innerHTML = renderEmpty('⚠️', e.message);
  }
}

function renderLogItem(log) {
  const isPos = log.amount > 0;
  const icon = log.type === 'reward' ? '⭐' : (log.type === 'deduct' ? '➖' : '🛠');
  const iconClass = log.type === 'reward' ? 'log-reward' : (log.type === 'deduct' ? 'log-deduct' : 'log-adjust');
  return `
    <div class="log-item">
      <div class="log-icon ${iconClass}">${icon}</div>
      <div class="log-info">
        <div class="log-reason">${esc(log.reason || log.task_title || '积分变动')}</div>
        <div class="log-time">${esc(log.created_at)}</div>
      </div>
      <div class="log-amount ${isPos ? 'pos' : 'neg'}">${isPos ? '+' : ''}${log.amount}</div>
    </div>`;
}

// 调整积分（加分/扣分）
function showAdjustModal(childId) {
  const child = state.children.find(c => c.id === childId);
  if (!child) return;
  openModal(`
    <div class="modal-title">调整 ${esc(child.child_name)} 的积分</div>
    <div class="form-group">
      <label>调整类型</label>
      <div class="category-select">
        <div class="cat-option active" data-adj="add" onclick="selectAdjType(this)">➕ 加分</div>
        <div class="cat-option" data-adj="deduct" onclick="selectAdjType(this)">➖ 扣分</div>
      </div>
    </div>
    <div class="form-group">
      <label>积分数额</label>
      <div class="points-stepper">
        <button class="stepper-btn" onclick="stepAdjust(-1)">−</button>
        <span class="points-value" id="adjust-amount">5</span>
        <button class="stepper-btn" onclick="stepAdjust(1)">+</button>
      </div>
    </div>
    <div class="form-group">
      <label>原因</label>
      <input type="text" id="adjust-reason" placeholder="例如：表现优秀/违反规则">
    </div>
    <div class="modal-actions">
      <button class="btn btn-outline" onclick="closeModal()">取消</button>
      <button class="btn btn-primary" onclick="submitAdjust(${childId})">确定</button>
    </div>
  `);
}

let adjustType = 'add';
let adjustAmount = 5;
function selectAdjType(el) {
  $$('.cat-option').forEach(x => x.classList.remove('active'));
  el.classList.add('active');
  adjustType = el.dataset.adj;
}
function stepAdjust(delta) {
  adjustAmount = Math.max(1, adjustAmount + delta);
  $('#adjust-amount').textContent = adjustAmount;
}
async function submitAdjust(childId) {
  const reason = $('#adjust-reason').value.trim() || '家长调整积分';
  const amount = adjustType === 'deduct' ? -adjustAmount : adjustAmount;
  try {
    await api('/points/adjust', 'POST', { child_id: childId, amount, reason, type: adjustType });
    showToast('积分已更新');
    closeModal();
    loadPoints();
  } catch (e) { showToast(e.message); }
}

// ========== 孩子管理（家长） ==========
async function loadChildren() {
  try {
    const data = await api('/children');
    state.children = data.children;
    $('#content').innerHTML = `
      <div class="info-block">💡 每个孩子都有自己的账号，用账号密码登录后即可认领任务、查看积分。</div>
      <div class="section-title">👦 孩子账户</div>
      ${state.children.length === 0 ? renderEmpty('👶', '还没有孩子账户，点击下方按钮添加') : state.children.map(c => `
        <div class="card" style="display:flex;align-items:center;gap:12px">
          <span class="avatar" style="background:${c.avatar_color}">${esc(c.child_name).slice(0,1)}</span>
          <div style="flex:1">
            <div class="rank-name">${esc(c.child_name)}</div>
            <div style="font-size:12px;color:var(--text-light)">账号：${esc(c.username)}</div>
          </div>
          <div style="text-align:right">
            <div style="color:var(--warning);font-weight:700;font-size:18px">${c.points} 分</div>
          </div>
        </div>`).join('')}
      <button class="btn btn-primary btn-block" style="margin-top:14px" onclick="showAddChildModal()">＋ 添加孩子</button>
    `;
  } catch (e) {
    $('#content').innerHTML = renderEmpty('⚠️', e.message);
  }
}

function showAddChildModal() {
  openModal(`
    <div class="modal-title">添加孩子</div>
    <div class="form-group"><label>孩子姓名</label><input type="text" id="child-name" placeholder="例如：小明"></div>
    <div class="form-group"><label>登录账号</label><input type="text" id="child-username" placeholder="例如：xiaoming"></div>
    <div class="form-group"><label>登录密码</label><input type="password" id="child-password" placeholder="设置密码"></div>
    <div class="form-group"><label>头像颜色</label>
      <div style="display:flex;gap:8px;flex-wrap:wrap" id="color-picker">
        ${COLORS.map(c => `<div class="color-dot" data-color="${c}" style="background:${c}" onclick="pickColor(this)"></div>`).join('')}
      </div>
    </div>
    <div class="modal-actions">
      <button class="btn btn-outline" onclick="closeModal()">取消</button>
      <button class="btn btn-primary" onclick="addChild()">添加</button>
    </div>
  `);
  selectedColor = COLORS[0];
}
let selectedColor = COLORS[0];
function pickColor(el) {
  $$('.color-dot').forEach(x => x.classList.remove('selected'));
  el.classList.add('selected');
  selectedColor = el.dataset.color;
}
async function addChild() {
  const name = $('#child-name').value.trim();
  const username = $('#child-username').value.trim();
  const password = $('#child-password').value;
  if (!name || !username || !password) return showToast('请填写完整信息');
  try {
    await api('/children', 'POST', { child_name: name, username, password, avatar_color: selectedColor });
    showToast('孩子账户已创建！');
    closeModal();
    loadChildren();
  } catch (e) { showToast(e.message); }
}

// ========== 孩子"我的"页 ==========
function renderProfile() {
  const u = state.user;
  $('#content').innerHTML = `
    <div class="points-hero">
      <div class="big-label">${esc(u.child_name)} 的积分</div>
      <div class="big-number">${u.points ?? 0}</div>
    </div>
    <div class="card">
      <div class="task-meta" style="flex-direction:column;gap:8px">
        <div>👤 姓名：${esc(u.child_name)}</div>
        <div>🔑 账号：${esc(u.username)}</div>
        <div>🏆 当前积分：${u.points ?? 0} 分</div>
      </div>
    </div>
    <div class="info-block">💡 完成认领的任务，拍照提交后由家长审核，通过就能获得积分啦！</div>
  `;
}

// ========== 初始化 ==========
function init() {
  // 登录切换
  $$('.login-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      $$('.login-tab').forEach(x => x.classList.remove('active'));
      tab.classList.add('active');
    });
  });

  $('#login-btn').addEventListener('click', doLogin);

  // 退出登录
  $('#logout-btn').addEventListener('click', () => {
    if (confirm('确定退出登录吗？')) logout();
  });

  // 判断是否已登录
  if (state.token && state.user) {
    showApp();
  } else {
    showLogin();
  }
}

async function doLogin() {
  const username = $('#login-username').value.trim();
  const password = $('#login-password').value;
  const role = $$('.login-tab.active')[0]?.dataset.role;
  if (!username || !password) return showToast('请输入用户名和密码');
  $('#login-btn').disabled = true;
  $('#login-btn').textContent = '登录中...';
  try {
    const data = await api('/login', 'POST', { username, password });
    // 校验角色是否匹配（家长选家长登录）
    if (role && data.user.role !== role) {
      // 允许交叉，但提示
    }
    saveSession(data.token, data.user);
    showToast(`欢迎回来，${data.user.role === 'parent' ? '家长' : data.user.child_name}！`);
    showApp();
  } catch (e) {
    $('#login-error').textContent = e.message;
  } finally {
    $('#login-btn').disabled = false;
    $('#login-btn').textContent = '登 录';
  }
}

// 全局暴露给 HTML onclick
window.showTaskDetail = showTaskDetail;
window.deleteTask = deleteTask;
window.claimTask = claimTask;
window.showChildTask = showChildTask;
window.showSubmitModal = showSubmitModal;
window.submitTask = submitTask;
window.selectCat = selectCat;
window.stepPoints = stepPoints;
window.publishTask = publishTask;
window.stepAuditPoints = stepAuditPoints;
window.reviewSubmission = reviewSubmission;
window.showAdjustModal = showAdjustModal;
window.selectAdjType = selectAdjType;
window.stepAdjust = stepAdjust;
window.submitAdjust = submitAdjust;
window.showAddChildModal = showAddChildModal;
window.pickColor = pickColor;
window.addChild = addChild;

// 启动
document.addEventListener('DOMContentLoaded', init);

// 孩子家务/作业积分管理系统 - 后端入口
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 8080;
const JWT_SECRET = process.env.JWT_SECRET || 'child-points-secret-key-2026';

// ============ 中间件 ============
app.use(cors());
// 增大请求体限制以支持 base64 图片
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));
// 静态文件（前端）
app.use(express.static(path.join(__dirname, '..', 'public')));

// ============ 认证中间件 ============
function auth(req, res, next) {
  const token = req.headers['authorization']?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: '未登录' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = db.getUserById(decoded.id);
    if (!req.user) return res.status(401).json({ error: '用户不存在' });
    next();
  } catch (e) {
    return res.status(401).json({ error: '登录已过期' });
  }
}

function requireParent(req, res, next) {
  if (req.user.role !== 'parent') return res.status(403).json({ error: '需要家长权限' });
  next();
}

function requireChild(req, res, next) {
  if (req.user.role !== 'child') return res.status(403).json({ error: '需要孩子权限' });
  next();
}

// ============ 认证 API ============
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: '请输入用户名和密码' });
  const user = db.getUserByUsername(username.trim());
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: '用户名或密码错误' });
  }
  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, username: user.username, role: user.role, child_name: user.child_name, avatar_color: user.avatar_color, points: user.points } });
});

app.get('/api/me', auth, (req, res) => {
  res.json({ user: req.user });
});

// ============ 孩子管理（家长） ============
app.get('/api/children', auth, requireParent, (req, res) => {
  res.json({ children: db.getChildren() });
});

app.post('/api/children', auth, requireParent, (req, res) => {
  const { username, password, child_name, avatar_color } = req.body;
  if (!username || !password || !child_name) {
    return res.status(400).json({ error: '请填写完整信息（用户名、密码、姓名）' });
  }
  if (db.getUserByUsername(username.trim())) {
    return res.status(400).json({ error: '用户名已存在' });
  }
  const hash = bcrypt.hashSync(password, 10);
  const color = avatar_color || '#4F8EF7';
  const id = db.createChild(username.trim(), hash, child_name.trim(), color);
  res.json({ child: db.getUserById(id) });
});

// 更新孩子信息（含改名/改积分初值）
app.put('/api/children/:id', auth, requireParent, (req, res) => {
  const { child_name, avatar_color, points } = req.body;
  const child = db.getUserById(req.params.id);
  if (!child || child.role !== 'child') return res.status(404).json({ error: '孩子不存在' });
  const db2 = require('better-sqlite3');
  // 简单更新
  const stmt = db.db.prepare(`UPDATE users SET child_name=COALESCE(?, child_name), avatar_color=COALESCE(?, avatar_color) WHERE id=?`);
  stmt.run(child_name || null, avatar_color || null, req.params.id);
  // 如有初始积分调整，写日志
  if (points !== undefined && points !== child.points) {
    const diff = points - child.points;
    db.addPointsLog({ child_id: child.id, task_id: null, amount: diff, type: 'adjust', reason: '家长调整初始积分', created_by: req.user.id });
  }
  res.json({ child: db.getUserById(req.params.id) });
});

app.delete('/api/children/:id', auth, requireParent, (req, res) => {
  const child = db.getUserById(req.params.id);
  if (!child) return res.status(404).json({ error: '孩子不存在' });
  db.db.prepare(`DELETE FROM users WHERE id=?`).run(req.params.id);
  res.json({ success: true });
});

// ============ 任务 API ============
// 家长发布任务
app.post('/api/tasks', auth, requireParent, (req, res) => {
  const { title, category, description, base_points, assigned_to, deadline } = req.body;
  if (!title || !base_points) {
    return res.status(400).json({ error: '请填写任务名称和积分' });
  }
  const id = db.createTask({
    title: title.trim(),
    category: category || 'chore',
    description: description || '',
    base_points: parseInt(base_points) || 5,
    assigned_to: assigned_to || null,
    created_by: req.user.id,
    deadline: deadline || null
  });
  // 若指定了孩子，任务直接进入"已认领"状态
  res.json({ task: db.getTaskById(id) });
});

// 获取单个任务
app.get('/api/tasks/:id', auth, (req, res) => {
  const task = db.getTaskById(req.params.id);
  if (!task) return res.status(404).json({ error: '任务不存在' });
  if (req.user.role === 'child') {
    const allowed = task.status === 'pending' || task.assigned_to === req.user.id || task.claimed_by === req.user.id;
    if (!allowed) return res.status(403).json({ error: '无权查看该任务' });
  }
  res.json({ task });
});

// 获取任务列表（家长看全部，孩子看相关的）
app.get('/api/tasks', auth, (req, res) => {
  let tasks = db.getTasks();
  if (req.user.role === 'child') {
    // 孩子只能看到：1) 开放认领的 2) 自己认领/被指定的
    tasks = tasks.filter(t =>
      t.status === 'pending' ||
      t.assigned_to === req.user.id ||
      t.claimed_by === req.user.id
    );
    // 附加孩子是否已提交
    tasks = tasks.map(t => ({
      ...t,
      has_submission: !!db.db.prepare(`SELECT id FROM submissions WHERE task_id=? AND child_id=?`).get(t.id, req.user.id)
    }));
  }
  res.json({ tasks });
});

// 孩子认领任务
app.post('/api/tasks/:id/claim', auth, requireChild, (req, res) => {
  const task = db.getTaskById(req.params.id);
  if (!task) return res.status(404).json({ error: '任务不存在' });
  if (task.status !== 'pending') return res.status(400).json({ error: '该任务已被认领或不可认领' });
  if (task.assigned_to && task.assigned_to !== req.user.id) {
    return res.status(403).json({ error: '该任务是指定给其他孩子的' });
  }
  db.updateTaskStatus(task.id, 'claimed', { claimed_by: req.user.id, claimed_at: new Date().toLocaleString('zh-CN', { hour12: false }) });
  // 若任务本来指定给该孩子但状态是pending，这里也认领成功
  res.json({ task: db.getTaskById(task.id) });
});

// 孩子提交完成（上传图片+备注）
app.post('/api/tasks/:id/submit', auth, requireChild, (req, res) => {
  const task = db.getTaskById(req.params.id);
  if (!task) return res.status(404).json({ error: '任务不存在' });
  if (task.claimed_by !== req.user.id) {
    return res.status(403).json({ error: '你还没有认领这个任务' });
  }
  if (task.status !== 'claimed') return res.status(400).json({ error: '该任务当前状态不可提交' });
  const { image, note } = req.body;
  if (!image) return res.status(400).json({ error: '请上传完成照片' });
  db.createSubmission(task.id, req.user.id, image, note || '');
  db.updateTaskStatus(task.id, 'completed');
  res.json({ task: db.getTaskById(task.id) });
});

// 家长撤回/关闭任务
app.delete('/api/tasks/:id', auth, requireParent, (req, res) => {
  db.db.prepare(`DELETE FROM tasks WHERE id=?`).run(req.params.id);
  res.json({ success: true });
});

// ============ 审核 API ============
// 家长查看待审核提交
app.get('/api/submissions', auth, requireParent, (req, res) => {
  const all = db.getSubmissions();
  // 只返回任务状态为 completed（待审核）的提交
  res.json({ submissions: all });
});

// 审核提交
app.post('/api/submissions/:id/review', auth, requireParent, (req, res) => {
  const sub = db.getSubmissionById(req.params.id);
  if (!sub) return res.status(404).json({ error: '提交不存在' });
  const { approve, actual_points, reject_reason } = req.body;
  const task = db.getTaskById(sub.task_id);
  if (!task) return res.status(404).json({ error: '任务不存在' });

  if (approve) {
    // 通过：确定实际积分，发放到孩子账户
    const points = actual_points !== undefined ? parseInt(actual_points) : task.base_points;
    db.updateTaskStatus(task.id, 'approved', { approved_at: new Date().toLocaleString('zh-CN', { hour12: false }), actual_points: points });
    db.addPointsLog({ child_id: sub.child_id, task_id: task.id, amount: points, type: 'reward', reason: `完成任务：${task.title}`, created_by: req.user.id });
    // 清理提交（已归档，积分已记）
    db.deleteSubmission(sub.id);
  } else {
    // 驳回：任务退回认领状态，可重新提交
    db.updateTaskStatus(task.id, 'claimed', { reject_reason: reject_reason || '家长驳回，请重新完成' });
    db.deleteSubmission(sub.id);
  }
  res.json({ task: db.getTaskById(task.id) });
});

// ============ 积分 API ============
// 家长手动调整积分（加分/扣分）
app.post('/api/points/adjust', auth, requireParent, (req, res) => {
  const { child_id, amount, reason, type } = req.body;
  const child = db.getUserById(child_id);
  if (!child || child.role !== 'child') return res.status(404).json({ error: '孩子不存在' });
  if (!amount || amount === 0) return res.status(400).json({ error: '请输入调整积分数额' });
  const amt = parseInt(amount);
  const t = type || (amt < 0 ? 'deduct' : 'adjust');
  db.addPointsLog({ child_id: child.id, task_id: null, amount: amt, type: t, reason: reason || '家长调整积分', created_by: req.user.id });
  res.json({ child: db.getUserById(child.id) });
});

// 积分流水
app.get('/api/points/logs', auth, (req, res) => {
  const child_id = req.user.role === 'child' ? req.user.id : (req.query.child_id || null);
  res.json({ logs: db.getPointsLogs(child_id) });
});

// ============ 健康检查 ============
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// 前端路由回退
app.get(/^\/(?!api).*/, (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// ============ 启动 ============
app.listen(PORT, '0.0.0.0', () => {
  console.log(`✔ 孩子积分管理系统已启动: http://localhost:${PORT}`);
  console.log(`   家长账号: parent / 123456`);
});

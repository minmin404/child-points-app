// 数据库初始化与数据访问层 (使用 Node 22 内置 node:sqlite)
const { DatabaseSync } = require('node:sqlite');
const path = require('path');
const fs = require('fs');

// 数据库文件位置（可用环境变量覆盖，便于云平台配置）
const dbDir = process.env.DB_DIR || path.join(__dirname, '..', 'data');
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}
const dbFile = process.env.DB_FILE || path.join(dbDir, 'points.db');
const db = new DatabaseSync(dbFile);

// 开启外键约束
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

// ============ 建表 ============
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'child',   -- parent / child
  child_name TEXT,                      -- 孩子姓名（孩子角色）
  avatar_color TEXT DEFAULT '#4F8EF7',
  points INTEGER DEFAULT 0,             -- 孩子当前积分
  created_at TEXT DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'chore',  -- chore家务 / homework作业
  description TEXT,
  base_points INTEGER NOT NULL DEFAULT 5,
  assigned_to INTEGER,                  -- 指定孩子id，NULL=可认领
  status TEXT NOT NULL DEFAULT 'pending', -- pending待领取/claimed已认领/completed待审核/approved已通过/rejected已驳回/expired已过期
  created_by INTEGER NOT NULL,
  created_at TEXT DEFAULT (datetime('now', 'localtime')),
  deadline TEXT,
  claimed_by INTEGER,                   -- 认领的孩子id
  claimed_at TEXT,
  approved_at TEXT,
  actual_points INTEGER,                -- 实际发放积分（审核时确定）
  reject_reason TEXT
);

CREATE TABLE IF NOT EXISTS submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL,
  child_id INTEGER NOT NULL,
  image TEXT,                           -- base64图片
  note TEXT,                            -- 孩子备注
  submitted_at TEXT DEFAULT (datetime('now', 'localtime')),
  FOREIGN KEY (task_id) REFERENCES tasks(id),
  FOREIGN KEY (child_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS points_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  child_id INTEGER NOT NULL,
  task_id INTEGER,                      -- 关联任务（可选）
  amount INTEGER NOT NULL,              -- 正数加分，负数扣分
  type TEXT NOT NULL DEFAULT 'reward',  -- reward任务奖励 / adjust家长调整 / deduct扣分
  reason TEXT,
  created_by INTEGER NOT NULL,
  created_at TEXT DEFAULT (datetime('now', 'localtime'))
);
`);

// 默认家长账号（如果不存在）
const parentCount = db.prepare(`SELECT COUNT(*) as c FROM users WHERE role='parent'`).get().c;
if (parentCount === 0) {
  const bcrypt = require('bcryptjs');
  const hash = bcrypt.hashSync('123456', 10);
  db.prepare(`INSERT INTO users (username, password_hash, role, child_name) VALUES (?, ?, ?, ?)`)
    .run('parent', hash, 'parent', '家长');
  console.log('✔ 已创建默认家长账号: 用户名 parent / 密码 123456');
}

// ============ 数据访问函数 ============
const now = () => new Date().toLocaleString('zh-CN', { hour12: false });

const dbHelper = {
  db,
  getUsers() {
    return db.prepare(`SELECT id, username, role, child_name, avatar_color, points FROM users`).all();
  },
  getChildren() {
    return db.prepare(`SELECT id, username, child_name, avatar_color, points, created_at FROM users WHERE role='child'`).all();
  },
  getUserById(id) {
    return db.prepare(`SELECT id, username, role, child_name, avatar_color, points FROM users WHERE id=?`).get(id);
  },
  getUserByUsername(username) {
    return db.prepare(`SELECT * FROM users WHERE username=?`).get(username);
  },
  createChild(username, passwordHash, childName, color) {
    const r = db.prepare(`INSERT INTO users (username, password_hash, role, child_name, avatar_color) VALUES (?,?,?,?,?)`)
      .run(username, passwordHash, 'child', childName, color);
    return r.lastInsertRowid;
  },
  getTasks() {
    return db.prepare(`SELECT * FROM tasks ORDER BY created_at DESC`).all();
  },
  getTaskById(id) {
    return db.prepare(`SELECT * FROM tasks WHERE id=?`).get(id);
  },
  createTask({ title, category, description, base_points, assigned_to, created_by, deadline }) {
    const r = db.prepare(`
      INSERT INTO tasks (title, category, description, base_points, assigned_to, created_by, deadline, status, claimed_by)
      VALUES (?,?,?,?,?,?,?,?, ?)
    `).run(title, category, description, base_points, assigned_to, created_by, deadline,
      assigned_to ? 'claimed' : 'pending',
      assigned_to || null);
    return r.lastInsertRowid;
  },
  updateTaskStatus(id, status, extra = {}) {
    const fields = ['status=?'];
    const params = [status];
    const allowed = ['claimed_by', 'claimed_at', 'approved_at', 'actual_points', 'reject_reason'];
    for (const key of allowed) {
      if (extra[key] !== undefined) {
        fields.push(`${key}=?`);
        params.push(extra[key]);
      }
    }
    params.push(id);
    return db.prepare(`UPDATE tasks SET ${fields.join(',')} WHERE id=?`).run(...params);
  },
  getSubmissions() {
    const sql = `SELECT s.*, t.title as task_title, t.base_points, t.category, t.status as task_status,
                        u.child_name as child_name FROM submissions s
                 LEFT JOIN tasks t ON s.task_id = t.id
                 LEFT JOIN users u ON s.child_id = u.id
                 ORDER BY s.submitted_at DESC`;
    return db.prepare(sql).all();
  },
  createSubmission(task_id, child_id, image, note) {
    const r = db.prepare(`INSERT INTO submissions (task_id, child_id, image, note) VALUES (?,?,?,?)`)
      .run(task_id, child_id, image, note);
    return r.lastInsertRowid;
  },
  getSubmissionById(id) {
    return db.prepare(`
      SELECT s.*, t.title as task_title, t.base_points, t.category, u.child_name
      FROM submissions s
      LEFT JOIN tasks t ON s.task_id = t.id
      LEFT JOIN users u ON s.child_id = u.id
      WHERE s.id=?`).get(id);
  },
  deleteSubmission(id) {
    return db.prepare(`DELETE FROM submissions WHERE id=?`).run(id);
  },
  hasSubmission(task_id, child_id) {
    return !!db.prepare(`SELECT id FROM submissions WHERE task_id=? AND child_id=?`).get(task_id, child_id);
  },
  // 积分
  addPointsLog({ child_id, task_id, amount, type, reason, created_by }) {
    const r = db.prepare(`
      INSERT INTO points_log (child_id, task_id, amount, type, reason, created_by)
      VALUES (?,?,?,?,?,?)`).run(child_id, task_id, amount, type, reason, created_by);
    db.prepare(`UPDATE users SET points = points + ? WHERE id=?`).run(amount, child_id);
    return r.lastInsertRowid;
  },
  getPointsLogs(child_id) {
    let sql = `SELECT p.*, t.title as task_title FROM points_log p
               LEFT JOIN tasks t ON p.task_id = t.id`;
    if (child_id) {
      sql += ` WHERE p.child_id = ?`;
    }
    sql += ` ORDER BY p.created_at DESC, p.id DESC`;
    return db.prepare(sql).all(...(child_id ? [child_id] : []));
  },
  getChildPoints(child_id) {
    return db.prepare(`SELECT points FROM users WHERE id=?`).get(child_id);
  }
};

module.exports = dbHelper;
